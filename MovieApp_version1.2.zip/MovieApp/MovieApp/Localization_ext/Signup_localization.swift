//
//  Signup_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 28/01/2023.
//

import Foundation

extension SignUpView {
    // know variable that changes text based on the language
    var usernameK: String {
       // know key
       let format = NSLocalizedString("userNameL", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var passwordK: String {
       let format = NSLocalizedString("passwordL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var emailK: String {
       let format = NSLocalizedString("emailL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var SignUPK: String {
       let format = NSLocalizedString("SignUPL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var comfirmPassK: String {
       let format = NSLocalizedString("comfirmPassKL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var AlreadyaccounK: String {
       let format = NSLocalizedString("AlreadyaccounKL", comment: "")
       return String.localizedStringWithFormat(format)
    }
}
