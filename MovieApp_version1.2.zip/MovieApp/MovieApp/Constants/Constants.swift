//
//  Constants.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct Images {
    static let logo = Image("PopCornIcon")
    
    // MARK: - Backgrounds
    static let bg1 = Image("bg1")
    static let bg2 = Image("bg2")
    static let bg3 = Image("bg3")
    static let bg4 = Image("bg4")
    
    // MARK: - Posters
    static let movie1 = Image("a_million_ways_to_die_in_the_west")
    static let movie2 = Image("black-adam")
    static let movie3 = Image("black-panther-wakanda-forever")
    static let movie4 = Image("edge_of_tomorrow")
    static let movie5 = Image("hangover_part_2")
    static let movie6 = Image("Jaws")
    static let movie7 = Image("Joker")
    static let movie8 = Image("Sully-Clint-Eastwood-Tom-Hanks")
    static let movie9 = Image("The_Man_From_UNCLE")
    static let movie10 = Image("The-Lord-Of-The-Rings-The-Two-Towers")
    static let movie11 = Image("The-Meg")
    
    // MARK: - Cast
    static let dwayn = Image("dwayn")
    static let pierce = Image("pierce")
    static let aldis = Image("aldis")
    static let blunt = Image("blunt")
    static let cruise = Image("cruise")
    static let bradley = Image("bradley")
    static let ed = Image("ed")
    static let justin = Image("justin")
    static let zack = Image("zack")
    static let roy = Image("roy")
    static let shaw = Image("shaw")
    static let deniro = Image("deniro")
    static let joaquin = Image("joaquin")
    static let binbing = Image("bingbing")
    static let statham = Image("statham")
    static let dania = Image("dania")
    static let letitia = Image("letitia")
    static let lupita = Image("lupita")
    static let ian = Image("ian")
    static let wood = Image("wood")
    static let hanks = Image("hanks")
    static let laura = Image("laura")
    static let hammer = Image("hammer")
    static let henry = Image("henry")
    static let alicia = Image("alicia")
    static let charlize = Image("charlize")
    static let liam = Image("liam")
    static let seth = Image("seth")
}

struct Colors {
    static let color1 = Color(hex:"")
    static let color2 = Color(hex:"")
}
