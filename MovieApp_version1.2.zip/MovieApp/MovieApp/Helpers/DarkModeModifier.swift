//
//  DarkModeModifier2.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 28/01/2023.
//

import SwiftUI

public struct DarkModeViewModifier: ViewModifier {

    @AppStorage("isDarkMode") var isDarkMode: Bool = true

    public func body(content: Content) -> some View {
        content
            .environment(\.colorScheme, isDarkMode ? .dark : .light)
            .preferredColorScheme(isDarkMode ? .dark : .light) // tint on status bar
    }
}
