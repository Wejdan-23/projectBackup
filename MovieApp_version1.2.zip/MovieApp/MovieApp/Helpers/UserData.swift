//
//  UserData.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 27/01/2023.
//

import SwiftUI

//struct UserData: View {
//    @State var username = ""
//    @State var SavedName = ""
//    var body: some View {
//        VStack{
//            Text("\(SavedName)")
//            Spacer()
//            Text("Enter Your Name")
//            TextField("Enter Your Name", text: $username)
//            Button(action:{saveData() }) {
//                Text("Submit/Save")
//            }
//            Spacer()
//        }.onAppear (perform: {
//            getData()
//        })
//    }
//
//    func saveData() {
//        UserDefaults.standard.set(self.username, forKey: "UserName")
//    }
//    func getData() {
//        SavedName = "Welcome: \(UserDefaults.standard.string(forKey: "UserName") ?? "")"
//    }
//}
