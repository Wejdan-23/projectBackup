//
//  MovieViewModel.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import Foundation

class MovieViewModel: ObservableObject {
    @Published var movies = Movie.movies
    @Published var filteredMovies = [Movie]()
    
    func filterBy(title: String = "") {
        filteredMovies = title.isEmpty ? movies : movies.filter {$0.title.lowercased().contains(title.lowercased())}
    }
    
    func filterByGenre(genre: Genre = Genre.Action) {
        filteredMovies = movies.filter {$0.genre.contains(genre)}
    }
}
