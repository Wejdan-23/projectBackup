//
//  SearchView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 27/01/2023.
//

import SwiftUI

struct SearchView: View {
    @Binding var text: String
    @ObservedObject var model = MovieViewModel()
    @State private var searchCriteria: String = "Title"
    @State private var whatGenre: Genre = .Action
    
    var body: some View {
        HStack(spacing: 8) {
            
            // MARK: - Clear Search Button
            Button(action: {
                self.text = ""
            }) {
                Image(systemName: "xmark")
                    .foregroundColor(.red)
                    .bold()
                    .font(.title3)
                    .padding()
                    .background(.ultraThickMaterial, in: Circle())
            }
            
            // MARK: - Search By Title / Genre
            HStack {
                if searchCriteria == "Title" {
                    Image(systemName: "magnifyingglass")
                        .font(.body)
                        .foregroundColor(.secondary)
                    
                    TextField("Search Movie", text: $text)
                        .foregroundColor(.primary)
                        .font(.body)
                        .padding(16)
                        .cornerRadius(8)
                        .onChange(of: text) { newValue in
                            model.filterBy(title: newValue)
                        }
                        .onAppear {
                            model.filterBy()
                        }
                } else if searchCriteria == "Genre" {
                    Menu {
                        ForEach(Genre.allCases, id: \.self) { genre in
                            Button {
                                whatGenre = genre
                            } label: {
                                Text(genre.rawValue)
                                    .foregroundColor(.primary)
                                    .font(.body)
                                    .bold()
                            }
                        }
                    } label: {
                        HStack {
                            Text(whatGenre.rawValue)
                                .foregroundColor(.primary)
                                .font(.body)
                                .padding()
                        }
                    }
                    .onChange(of: whatGenre) { newValue in
                        model.filterByGenre(genre: whatGenre)
                    }
                    .onAppear {
                        model.filterByGenre()
                    }
                }
            }
            .padding(.horizontal, 10)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
            
            // MARK: - Search By
            HStack {
                Text("By:")
                    .foregroundColor(.primary)
                    .bold()
                HStack {
                    SearchCriteriaView(searchCriteria: $searchCriteria)
                }
                .padding(.trailing)
                
            }
            .padding()
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
        }
        
        // MARK: - List filtered movies
        VStack {
            ScrollView(.vertical) {
                ScrollView(.horizontal) {
                    LazyHGrid(rows: Array(repeating: GridItem(.flexible(), spacing: 15), count: 1), spacing: 15) {
                        ForEach(model.filteredMovies) { movie  in    
                            NavigationLink(destination: MovieDetailsView(movie: movie).navigationBarBackButtonHidden(true)) {
                                VStack {
                                    movie.poster
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .mask(RoundedRectangle(cornerRadius: 20))
                                        .frame(width: UIScreen.main.bounds.width/1.4)
                                    
                                    Text(movie.title)
                                        .font(.title3)
                                        .foregroundColor(.primary)
                                        .bold()
                                    
                                    HStack {
                                        ForEach(movie.genre, id: \.self) { genre in
                                            Text(genre.rawValue)
                                                .foregroundColor(.primary)
                                                .padding(8)
                                                .background(.orange, in: Capsule())
                                        }
                                    }
                                }
                                .padding()
                                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                            }
                        }
                    }
                }
            }
        }
        .padding()
    }
}

//struct SearchView_Previews: PreviewProvider {
//    static var previews: some View {
//        SearchView(text: .constant(""))
//    }
//}
