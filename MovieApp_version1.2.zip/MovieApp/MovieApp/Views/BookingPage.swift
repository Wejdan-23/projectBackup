//
//  BookingPage.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct BookingPage: View {
    
    @State private var selectedSeatId: Int = -1
    @State private var selectedSeat: Seat?
    @State private var seats = Seat.seats
    var movie: Movie
    
    var body: some View {
        ZStack{
            VStack(spacing: 16) {
                ZStack {
                    // MARK: - Seats Image
                    VStack {
                        Image(systemName: "tv")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .padding()
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 15), count: 5), spacing: 15) {
                                ForEach(seats) { seat in
                                    Button {
                                        if !seat.reserved {
                                            selectedSeatId = seat.id
                                            selectedSeat = seat
                                        }
                                    } label: {
                                        if seat.reserved {
                                            seat.image
                                                .font(.largeTitle)
                                                .foregroundColor(.purple)
                                        } else {
                                            seat.image
                                                .font(.largeTitle)
                                                .foregroundColor(selectedSeatId == seat.id ? .green : .gray)
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal)
                    }
                    .padding()
                }
                .background(.black)
                .cornerRadius(24)
                
                // MARK: Seat Key
                HStack(spacing: 16) {
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.purple)
                        Text("Reserved")
                    }
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.green)
                        Text("Selected")
                    }
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.gray)
                        Text("Availble")
                    }
                }
                .padding()
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack{
                        HStack {
                            Text("Selected Seat:")
                                .foregroundColor(.primary)
                                .font(.title3)
                                .padding()
                            Text(selectedSeat == nil ? "None" : "E\(selectedSeat!.id)")
                                .font(.body)
                                .foregroundColor(.secondary)
                                .padding()
                        }
                        .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                        
                        HStack{
                            Text("Total:")
                                .font(.title3)
                                .foregroundColor(.primary)
                                .padding()
                            Text(selectedSeat == nil ? "$0" : "$\(selectedSeat!.price)")
                                .font(.body)
                                .foregroundColor(.secondary)
                                .padding()
                        }
                    }
                        
                }
                .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                
                HStack{
                    VStack{
                        Text(movie.castDate, style: .date)
                            .padding(.horizontal)
                            .padding(.top)
                            .frame(width: UIScreen.main.bounds.width/2)
                        HStack {
                            Text("Time:")
                            Menu {
                                
                            } label: {
                                Text("12:05 am")
                            }
                        }
                        .padding()
                        
                    }
                    .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                    
                    VStack {
                        Text("Movie: \(movie.title)")
                            .font(.caption)
                            .bold()
                            .foregroundColor(.primary)
                            .lineLimit(3, reservesSpace: true)
                            .padding()
                    }
                    .background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                    
                }
                .padding()
                
                
                HStack{
                    Button{
                       
                    }label: {
                        Text("Buy Ticket")
                            .font(.title)
                            .foregroundColor(.white)
                            .bold()
                            .padding()
                    }
                    .background(.orange)
                    .cornerRadius(16)
                }
                .padding()
            }
            .padding()
        }
    }
}

struct BookingPage_Previews: PreviewProvider {
    static var previews: some View {
        BookingPage(movie: Movie.movies.first!)
    }
}
