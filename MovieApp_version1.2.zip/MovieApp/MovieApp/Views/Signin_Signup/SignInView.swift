//
//  SignInView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI
struct SignInView: View {
   
    @State var username = ""
    @State var email = ""
    @State var password = ""
    @State var confirmPassword = ""
    @AppStorage("shouldShowOnboarding") var shouldShowOnboarding: Bool = true
    
    var body: some View {
        NavigationStack {
            ZStack {
                Images.bg4
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)

               VStack {
                  ZStack {
                     // MARK: - UserName
                     VStack{
                         HStack {
                             Text("UserName:")
                                  .font(.title2)
                                  .bold()
                                  .foregroundColor(.primary)
                             Spacer()
                         }
                         .padding()
                         
                        HStack {
                            Image(systemName: "person")
                                .foregroundColor(.blue)
                                .font(.title3)
                           TextField("username", text: $username)
                                .font(.title3)
                                .foregroundColor(.primary)
                        }
                        .padding()
                        .background(.regularMaterial, in: Capsule())
                        
                         // MARK: - Email
                         HStack {
                             Text("Email:")
                                  .font(.title2)
                                  .foregroundColor(.primary)
                                  .bold()
                             Spacer()
                         }
                         .padding()
                         HStack {
                             Image(systemName: "envelope.open")
                                 .foregroundColor(.green)
                                 .font(.title3)
                             TextField("example@gmail.com", text: $email)
                                 .foregroundColor(.primary)
                                 .font(.title3)
                         }
                         .padding()
                         .background(.regularMaterial, in: Capsule())
                         
                         HStack {
                             Text("Password:")
                                .font(.title2)
                                .foregroundColor(.primary)
                                .bold()
                             Spacer()
                         }
                         .padding()
                         
                        HStack{
                           Image(systemName: "lock")
                                .foregroundColor(Color.red)
                                .font(.title3)
                           SecureField("********", text: $password)
                                .foregroundColor(.primary)
                                .font(.title3)
                        }
                        .padding()
                        .background(.regularMaterial, in: Capsule())

                         HStack {
                             Text("Dont have an account?")
                                 .foregroundColor(.primary)
                                 .font(.body)
                             NavigationLink(destination: SignUpView()) {
                                 Text("Sign UP")
                                     .font(.title3)
                                     .bold()
                             }
                         }
                         .padding(24)
                     }
                     .padding()
                     .frame(width: UIScreen.main.bounds.width - 80)
                  }
                  .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))

                   // Hide Back Button When Navigating
                   NavigationLink(destination: MainTabView().navigationBarBackButtonHidden(true)) {
                      
                       Text("Submit")
                           .font(.title2)
                           .bold()
                           .foregroundColor(Color.primary)
                           .frame(width: UIScreen.main.bounds.width - 120)
                           .padding()
                           .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16)).padding()
                   }
               }
               .padding()
                
            }
        }
        .fullScreenCover (isPresented: $shouldShowOnboarding, content: {
            OnboardingView(shouldShowOnboarding: $shouldShowOnboarding)
        })
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}
