//
//  ContentView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        SignInView()
            .modifier(DarkModeViewModifier())
    }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
