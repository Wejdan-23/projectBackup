//
//  Userdefaults_ext.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 28/01/2023.
//

import Foundation

extension UserDefaults {
    
    func ifUserExists(email: String) -> Bool {
        if UserDefaults.standard.object(forKey: email) != nil {
            return true
        } else {
            return false
        }
    }
    
    func removeUser(email: String) {
        removeObject(forKey: email)
        removeObject(forKey: "\(email)_favorites")
        removeObject(forKey: "\(email)_booked")
    }
    
}
