//
//  Seats.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 28/01/2023.
//

import SwiftUI

struct Seat: Identifiable {
    var id: Int
    var price: Int
    var image: Image
    var reserved: Bool
    
    static var seats: [Seat] = addSeats()
    
    static func addSeats() -> [Seat] {
        var mySeats: [Seat] = []
        var price: Int!
        var img: Image!
        
        var reservedArr: [Int] = []
        while (reservedArr.count < 9) {
            let random = Int.random(in: 1...30)
            reservedArr.append(random)
        }
        
        for i in 1...30 {
            var reserved = false
            if reservedArr.contains(i) { reserved = true } else { reserved = false }
            
            if i > 20 {
                price = 85
                img = Image(systemName: "chair.lounge.fill")
            }
            else {
                price = 55
                img = Image(systemName: "rectangle.roundedbottom.fill")
            }
            
            
            mySeats.append(Seat(id: i, price: price, image: img, reserved: reserved))
        }
        return mySeats
    }
    
}
