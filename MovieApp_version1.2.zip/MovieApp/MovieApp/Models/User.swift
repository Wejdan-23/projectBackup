//
//  User.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct User: Identifiable {
    var id = UUID()
    var name: String
    var email: String
    var password: String
    var image: Image
    var favorites: [Int] = []
    var booked: [Int] = []
   
    init(name: String, email: String, password: String, image: Image) {
        self.name = name
        self.email = email
        self.password = password
        self.image = image
        self.favorites =  UserDefaults.standard.object(forKey: "\(self.id)_favorites") as? [Int] ?? []
        self.booked = UserDefaults.standard.object(forKey: "\(self.id)_booked") as? [Int] ?? []
    }
}

extension User {
    static var users = [
        User(name: "Amer", email: "amer@example.com", password: "password", image: Images.bg1),
        User(name: "Wejdan", email: "wejdan@example.com", password: "password", image: Images.bg1),
        User(name: "Abdullah", email: "abdullah@example.com", password: "password", image: Images.bg1)
    ]
}
