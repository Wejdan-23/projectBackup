//
//  Movie.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

enum Genre: String, CaseIterable, Hashable {
    case Action, Comedy, Drama, Thriller, Crime, History, Documentary, Animation, SciFi, Horror, Mystery, Kids
}

enum OnAirStatus: String, CaseIterable {
    case Playing, ComingSoon = "Coming Soon", NotInThreater = "Not in theater", Popular
}

struct Movie: Identifiable {
    var id = UUID()
    var title: String
    var genre: [Genre]
    var duration: String
    var description: String
    var poster: Image
    var cast: [Cast]
    var review: Double
    var numReviews: Int
    var onAirStatus: OnAirStatus
    var castDate: Date
    
    static func convertStringToDate(_ str: String) -> Date {
        let dateFormatter = DateFormatter()
        
        // 29 October 2019 20:15:55
        dateFormatter.dateFormat = "dd MMM yyyy HH:mm:ss"
        return dateFormatter.date(from: str) ?? Date.now // Oct 29, 2019 at 7:15 PM
    }
}

extension Movie {
    static let movies: [Movie] = [
        .init(title: "A million ways to die in the west", genre: [.Action, .Comedy, .Thriller], duration: "02:00", description: "To be added...", poster: Images.movie1, cast: [Cast(name: "Parker", image: Images.bg1)], review: 3.5, numReviews: 4000, onAirStatus: .Popular, castDate: convertStringToDate("29 October 2022 20:15:55")),
        
        .init(title: "Black Adam", genre: [.Action, .Thriller], duration: "01:50", description: "Bruce Wayne", poster: Images.movie2, cast: [Cast(name: "Bruce", image: Images.movie2)], review: 4.5, numReviews: 7000, onAirStatus: .Popular, castDate: convertStringToDate("229 October 2022 20:15:55")),
        
        .init(title: "Black Panther", genre: [.Action], duration: "02:15", description: "Cryptonight", poster: Images.movie3, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2022 20:15:55")),
        
            .init(title: "Edge of tomorrow", genre: [.Action, .Mystery], duration: "02:15", description: "Cryptonight", poster: Images.movie4, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2022 20:15:55")),
        
            .init(title: "The Hangover", genre: [.Comedy], duration: "02:15", description: "Cryptonight", poster: Images.movie5, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2022 20:15:55")),
        
            .init(title: "Jaws", genre: [.Horror], duration: "02:00", description: "To be added...", poster: Images.movie6, cast: [Cast(name: "Parker", image: Images.bg1)], review: 3.5, numReviews: 4000, onAirStatus: .Popular, castDate: convertStringToDate("29 October 2019 20:15:55")),
        
            .init(title: "Joker", genre: [.Action, .Crime], duration: "01:50", description: "Bruce Wayne", poster: Images.movie7, cast: [Cast(name: "Bruce", image: Images.movie2)], review: 4.5, numReviews: 7000, onAirStatus: .Popular, castDate: convertStringToDate("29 October 2019 20:15:55")),
        
            .init(title: "Sully", genre: [.Action, .Drama], duration: "02:15", description: "Cryptonight", poster: Images.movie8, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2019 20:15:55")),
        
            .init(title: "The Man From Uncle", genre: [.Action, .Comedy, .Crime], duration: "02:15", description: "Cryptonight", poster: Images.movie9, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2019 20:15:55")),
        
            .init(title: "The Lord of The Rings", genre: [.Action, .SciFi, .Thriller, .Mystery], duration: "02:15", description: "Cryptonight", poster: Images.movie10, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2019 20:15:55")),
        
            .init(title: "The Meg", genre: [.Action, .SciFi, .Horror], duration: "02:15",
              description: "Cryptonight", poster: Images.movie11, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon, castDate: convertStringToDate("29 October 2019 20:15:55"))
    ]
}

