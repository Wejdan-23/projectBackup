//
//  Constants.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct Images {
    static let bg1 = Image("bg1")
    static let bg2 = Image("bg2")
    static let bg3 = Image("bg3")
    static let bg4 = Image("bg4")
    
    static let movie1 = Image("a_million_ways_to_die_in_the_west")
    static let movie2 = Image("black-adam")
    static let movie3 = Image("black-panther-wakanda-forever")
    static let movie4 = Image("edge_of_tomorrow")
    static let movie5 = Image("hangover_part_2")
    static let movie6 = Image("Jaws")
    static let movie7 = Image("Joker")
    static let movie8 = Image("Sully-Clint-Eastwood-Tom-Hanks")
    static let movie9 = Image("The_Man_From_UNCLE")
    static let movie10 = Image("The-Lord-Of-The-Rings-The-Two-Towers")
    static let movie11 = Image("The-Meg")
    
    static let logo = Image("PopCornIcon")
}

struct Colors {
    static let color1 = Color(hex:"")
    static let color2 = Color(hex:"")
}
