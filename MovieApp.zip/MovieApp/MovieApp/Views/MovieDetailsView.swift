//
//  MovieDetailsView.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct MovieDetailsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var movie: Movie
    
    var body: some View {
        ZStack{
            RoundedRectangle(cornerRadius: 30).ignoresSafeArea()
                .background(.thickMaterial)
            VStack {
                ZStack{
                    VStack {
                        ZStack {
                            movie.poster
                                .resizable()
                                .cornerRadius(24)
                            .ignoresSafeArea(.all , edges: .top)
                            
                            VStack {
                                HStack{
                                    Button{
                                        self.presentationMode.wrappedValue.dismiss()
                                    }label: {
                                        Image(systemName: "x.circle")
                                            .font(.title)
                                            .foregroundColor(.white)
                                            .padding(4)
                                            .background(.ultraThinMaterial , in: Circle())
                                            .overlay{
                                                RoundedRectangle(cornerRadius: 20)
                                                    .stroke(.white , lineWidth: 1)
                                            }
                                        Spacer()
                                        HStack {
                                            Image(systemName: "clock")
                                                .font(.title3)
                                                .foregroundColor(.white)
                                                .padding(4)
//                                                .background(.ultraThinMaterial , in: Circle())
                                            Text(movie.duration)
                                                .font(.title2)
                                                .foregroundColor(.white)
                                                .padding(4)
                                            
                                        }.background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 20))
                                            .overlay{
                                                RoundedRectangle(cornerRadius: 20)
                                                    .stroke(.white , lineWidth: 1)
                                            }
                                    }
                                }.padding()
                                Spacer()
                            }
                        }
                        Text(movie.title)
                            .font(.largeTitle)
                        HStack{
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                            Text("\(movie.review.removeZerosFromEnd())")
                            Text("(\(movie.numReviews)) reviews")
                        }.padding(.horizontal)
                        List {
                            
                            VStack {
                                
                                Text(movie.description)
                                    .font(.title3)
                            }.listRowBackground(Color.clear)
                            //                    .frame(height: UIScreen.main.bounds.height/2)
                            //                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                                .ignoresSafeArea()
                        }.font(.title3)
                            .foregroundColor(.primary)
                            .listStyle(.insetGrouped)
                            .scrollContentBackground(.hidden)
                            .shadow(color: .primary, radius: 5, x: 5, y: 5)
                        
                        NavigationLink(destination: BookingPage()) {
                            Label("Booking", systemImage: "ticket.fill")
                                .font(.title)
                                .foregroundColor(.white)
                                .bold()
                                .padding()
                                .background(LinearGradient(colors: [.orange , .red , .red , .red], startPoint: .topLeading, endPoint: .bottomTrailing) , in: RoundedRectangle(cornerRadius: 20))
                        }
                    }
                }
            }
        }
    }
}

struct MovieDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        MovieDetailsView(movie: Movie.movies.first!)
    }
}
