//
//  MoviesTabView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 26/01/2023.
//

import SwiftUI

struct MoviesTabBtn: View {
    var title: String
    @Binding var selectedTab: String
    
    var body: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.5)) {
                selectedTab = title
            }
        }) {
            ZStack {
                Color.clear
                
                VStack() {
                    Text(title)
                        .fontWeight(.bold)
                        .foregroundColor(selectedTab == title ? Color.green : Color.secondary)
                }
            }
            .frame(width: UIScreen.main.bounds.width/3, height: 65)
            .background(selectedTab == title ? .thickMaterial : .ultraThinMaterial, in: Capsule())
        }
        .padding(10)
    }
}

