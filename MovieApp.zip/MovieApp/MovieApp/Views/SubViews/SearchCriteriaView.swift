//
//  SearchCriteriaView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 27/01/2023.
//

import SwiftUI

struct SearchCriteriaView: View {
    
    @Binding var searchCriteria: String
    
    var body: some View {
        Menu {
            Button { searchCriteria = "Title" }
        label: {
                Text("Title")
                .foregroundColor(.primary)
            }
            Button { searchCriteria = "Genre" } label: {
                Text("Genre")
            }
        } label : {
            Text(searchCriteria)
                .font(.body)
                .foregroundColor(.green)
                .bold()
        }  
    }
}
