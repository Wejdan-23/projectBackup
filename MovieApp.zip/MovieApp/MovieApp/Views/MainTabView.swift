//
//  TabView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct MainTabView: View {
   var movieK: String {
      let format = NSLocalizedString("movieL", comment:"")
      return String.localizedStringWithFormat(format)
   }
   var ticketK: String {
      let format = NSLocalizedString("ticketL", comment:"")
      return String.localizedStringWithFormat(format)
   }
   var ProfileK: String {
      let format = NSLocalizedString("ProfileL", comment:"")
      return String.localizedStringWithFormat(format)
   }
   var FavoritesK: String {
      let format = NSLocalizedString("FavoritesL", comment:"")
      return String.localizedStringWithFormat(format)
   }
    var body: some View {
        TabView {
           ReservedTicketsView()
               .tabItem {
                   Image(systemName: "ticket.fill")
                   Text(ticketK)
               }
           MoviesView()
               .tabItem {
                   Image(systemName: "popcorn.fill")
                   Text(movieK)
               }
           ProfileView()
               .tabItem {
                   Image(systemName: "person.fill")
                   Text(ProfileK)
               }
         
            
            FavoriteView()
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text(FavoritesK)
                }
           
        }
    }
}

struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
    }
}
