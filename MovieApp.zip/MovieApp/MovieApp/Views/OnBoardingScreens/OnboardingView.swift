//
//  Onboarding1.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct OnboardingView: View {
    @Binding var shouldShowOnboarding: Bool
   var  PopcornMoviesK: String {
      let format = NSLocalizedString("  PopcornMoviesL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var  WelcomePopcornK: String {
      let format = NSLocalizedString("  WelcomePopcornL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var SearchK: String {
      let format = NSLocalizedString(" SearchL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var LookFavoriteK: String {
      let format = NSLocalizedString(" LookFavoriteL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var FavoriteK: String {
      let format = NSLocalizedString(" FavoriteL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var convenienceK: String {
      let format = NSLocalizedString("  convenienceL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var NotificationsK: String {
      let format = NSLocalizedString("  NotificationsL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var SetupremindersK: String {
      let format = NSLocalizedString("  SetupremindersL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var EnjoyK: String {
      let format = NSLocalizedString("  EnjoyL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var PopcornK: String {
      let format = NSLocalizedString(" PopcornL", comment: "")
      return String.localizedStringWithFormat(format)
   }
    var body: some View {
        TabView {
            OBPageView(
               //"Welcome to the Popcorn Movie App"
                title: PopcornMoviesK,
                subtitle:  WelcomePopcornK,
                imageName: "popcorn",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
               //"Look up your Favorite movies"
                title: SearchK,
                subtitle: LookFavoriteK,
                imageName: "magnifyingglass",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
               //"Tag your favorites to book at your convenience"
                title: FavoriteK,
                subtitle: convenienceK,
                imageName: "heart",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
               //"Set up reminders for your booked movies"
                title: NotificationsK,
                subtitle:SetupremindersK,
                imageName: "bell.and.waves.left.and.right",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
               //"And don't forget to get some Popcorn!"
                title: EnjoyK,
                subtitle: PopcornK,
                imageName: "popcorn",
                showsDismissButton: true,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
        }
        .tabViewStyle(PageTabViewStyle())
        
    }
}
