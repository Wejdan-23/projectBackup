//
//  BookingPage.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct BookingPage: View {
    let data = (1...42).map { "Item \($0)" }

        let columns = [
            GridItem(.adaptive(minimum: 50))
        ]
    var body: some View {
        ZStack{
            LinearGradient(colors: [.black , .black ,.gray], startPoint: .top, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack{
                Text("Screen")
                    .foregroundColor(.white)
                // Screen Pic
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(data, id: \.self) { item in
                            Image(systemName: "rectangle.roundedbottom.fill"
)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.horizontal)
                Spacer()
                HStack{
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.white)
                        Text("Reserved")
                    }
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.yellow)
                        Text("Selected")
                    }
                    VStack{
                        Image(systemName: "rectangle.roundedbottom.fill")
                            .foregroundColor(.gray)
                        Text("Availble")
                    }
                }
                HStack{
                    VStack{
                        Text("Jan 27.2023")
                            .padding(.horizontal)
                            .padding(.top)
                            .frame(width: UIScreen.main.bounds.width/2)
                        Text("12:05")
                            .padding(.horizontal)
                            .padding(.bottom)
                    }.background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                    
                        
                    VStack{
                        Text("Seots")
                            .padding(.horizontal)
                            .padding(.top)
                            .frame(width: UIScreen.main.bounds.width/2)
                        Text("E1,E2,E3")
                            .padding(.horizontal)
                            .padding(.bottom)
                    }.background(.ultraThinMaterial , in: RoundedRectangle(cornerRadius: 16))
                    
                }.padding()
                HStack{
                    Spacer()
                    VStack{
                        Text("Total")
                            .font(.title3)
                            .foregroundColor(.gray)
                        Text("45 SR")
                    }
                    Spacer()
                    Button{
                       
                    }label: {
                        Text("Buy Ticket")
                            .font(.title)
                            .foregroundColor(.primary)
                            .padding()
                    }.background(.yellow)
                        .cornerRadius(16)
                    Spacer()
                }.padding()
            }
        }
    }
}

struct BookingPage_Previews: PreviewProvider {
    static var previews: some View {
        BookingPage()
    }
}

//let data = (1...100).map { "Item \($0)" }
//
//    let columns = [
//        GridItem(.adaptive(minimum: 80))
//    ]
//
//    var body: some View {
//        ScrollView {
//            LazyVGrid(columns: columns, spacing: 20) {
//                ForEach(data, id: \.self) { item in
//                    Text(item)
//                }
//            }
//            .padding(.horizontal)
//        }
//        .frame(maxHeight: 300)
//    }
