//
//  MoviesView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct MoviesView: View {
    
    @ObservedObject var model = MovieViewModel()
    @State private var searchText = ""
    @State private var selectedTab: String = "All"
    var scroll_Tabs = ["All", OnAirStatus.Popular.rawValue, OnAirStatus.ComingSoon.rawValue]

    var body: some View {
        ZStack {
            Images.bg4
                .resizable()
                .ignoresSafeArea(.all, edges: .top)
  
            VStack {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 0) {
                        ForEach(scroll_Tabs, id: \.self) { tab in
                            MoviesTabBtn(title: tab, selectedTab: $selectedTab)
                        }
                    }
                }
                .padding([.horizontal, .top])
                
                // MARK: - Tab bar Pages
                if selectedTab == "All" {
                    // MARK: - Search Bar
                    SearchView(text: $searchText)
                } else if selectedTab != "All" {
                    VStack {
                        ScrollView(.vertical, showsIndicators: false) {
                            ScrollView(.horizontal, showsIndicators: false) {
                                LazyHGrid(rows: Array(repeating: GridItem(.flexible(), spacing: 15), count: 1), spacing: 15) {
                                    ForEach(model.movies) { movie  in
                                        if movie.onAirStatus.rawValue == selectedTab {
                                            
                                            // MARK: - Need to Fix Navigation
                                            NavigationLink(destination: MovieDetailsView(movie: movie).navigationBarBackButtonHidden(true)) {
                                                MovieSectionsView(status: selectedTab, movie: movie)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .padding()
        }
        .onTapGesture { hideKeyboard() }
    }
}
