//
//  ProfileView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct ProfileView: View {
    @AppStorage("isNotificationOn") var isNotificationOn: Bool = true
    @AppStorage("isEnglish") private var language = LocalizationService.shared.language
    @State var isEnglish = (LocalizationService.shared.language == .english) ? true : false
    @AppStorage("isDarkMode") var isDarkMode: Bool = true
    @AppStorage("isPlayingSound") var isPlayingSound: Bool = true
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
   var AbdullahK: String {
      let format = NSLocalizedString("AbdullahL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var SettingsK: String {
      let format = NSLocalizedString("SettingsL", comment: "")
      return String.localizedStringWithFormat(format)
   }
 
   var   LanguageK: String {
      let format = NSLocalizedString("  LanguageL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var   NotificationsK: String {
      let format = NSLocalizedString("  NotificationsL", comment: "")
      return String.localizedStringWithFormat(format)
   }
 
   var    DarkModeK: String {
      let format = NSLocalizedString(" DarkModeL", comment: "")
      return String.localizedStringWithFormat(format)
   }
  
   var    SoundK: String {
      let format = NSLocalizedString("  SoundL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var   SignOutK: String {
      let format = NSLocalizedString("  SignOutL", comment: "")
      return String.localizedStringWithFormat(format)
   }
    var body: some View {
        ZStack {
            Images.bg4
                .resizable()
                .ignoresSafeArea(.all, edges: .top)
            
            VStack(spacing: 16) {
                ZStack {
                    VStack {
                        HStack{
                            Image(systemName: "person")
                                .font(.largeTitle)
                            Spacer()
                        }
                        VStack {
                           Image("profilepic")
                                .resizable()
                                .aspectRatio( contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                        }
                        .frame(width: 200, height: 200)
                        .mask(RoundedRectangle(cornerRadius: 30))
                        .shadow(color: Color(#colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)), radius: 16)
                        
                        HStack {
                            Image(systemName: "person.fill")
                                .font(.largeTitle)
                                .foregroundColor(.yellow)
                            Text(AbdullahK)
                                .font(.largeTitle)
                            .shadow(radius: 16)
                            Spacer()
                        }
                        
                        Divider()
                        
                        List {
                  Section(SettingsK) {
                                ProfileListRow(title: LanguageK, textColor: .primary, toggleAction: $isEnglish)
                                    .onChange(of: isEnglish) { newValue in
                                        if (newValue == true) { LocalizationService.shared.language = .english }
                                        else { LocalizationService.shared.language = .arabic }
                                    }
                                ProfileListRow(title: NotificationsK, textColor: .primary, toggleAction: $isNotificationOn)
                                ProfileListRow(title: DarkModeK, textColor: .primary, toggleAction: $isDarkMode)
                                ProfileListRow(title:  SoundK, textColor: .primary, toggleAction: $isPlayingSound)
                            }
                        }
                        .font(.title3)
                        .foregroundColor(.primary)
                        .listStyle(.grouped)
                        .scrollContentBackground(.hidden)
                        .shadow(color: .primary, radius: 5, x: 5, y: 5)
                        .frame(maxHeight: 200)
                        
                        Button{
                            self.presentationMode.wrappedValue.dismiss()
                        } label: {
                            Text( SignOutK)
                                .font(.title3)
                                .bold()
                                .foregroundColor(.primary)
                                .padding()
                        }
                        .padding()
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        .controlSize(.large)
                        .shadow(radius: 8)
                    }
                    .padding()
                }
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            }
            .padding()
        }
        .modifier(DarkModeViewModifier())
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
