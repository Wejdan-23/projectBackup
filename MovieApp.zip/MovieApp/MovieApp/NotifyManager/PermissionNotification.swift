//
//  PermissionNotification.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 05/07/1444 AH.
//

import SwiftUI

struct PermissionNotification: View {
    var body: some View {
        Button("Request Permission") {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
                if success {
                    print("All set!")
                } else if let error = error {
                    print(error.localizedDescription)
                }
            }
        }
    }
}

struct PermissionNotification_Previews: PreviewProvider {
    static var previews: some View {
        PermissionNotification()
    }
}
