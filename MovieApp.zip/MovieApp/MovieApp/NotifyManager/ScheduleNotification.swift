//
//  ScheduleNotification.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 05/07/1444 AH.
//

import SwiftUI

struct ScheduleNotification: View {
    var body: some View {
        Button("Schedule Notification") {
            let content = UNMutableNotificationContent()
            content.title = "Its Weekend"
            content.subtitle = "Its Movie Time"
            content.sound = UNNotificationSound.default

            // show this notification five seconds from now
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
            
            let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

            UNUserNotificationCenter.current().add(request)
        }
    }
}

struct ScheduleNotification_Previews: PreviewProvider {
    static var previews: some View {
        ScheduleNotification()
    }
}
