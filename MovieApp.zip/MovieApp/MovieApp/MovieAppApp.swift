//
//  MovieAppApp.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

@main
struct MovieAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
