//
//  Signin_localization.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 28/01/2023.
//

import Foundation

extension SignInView {
    var usernameK: String {
       // know key
       let format = NSLocalizedString("userNameL", comment:"")
       return String.localizedStringWithFormat(format)
    }
    var passwordK: String {
       let format = NSLocalizedString("passwordL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var emailK: String {
       let format = NSLocalizedString("emailL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var SignUPK: String {
       let format = NSLocalizedString("SignUPL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var accountK: String {
       let format = NSLocalizedString("accountL", comment: "")
       return String.localizedStringWithFormat(format)
    }
    var SubmitK: String {
       let format = NSLocalizedString("SubmitL", comment: "")
       return String.localizedStringWithFormat(format)
    }
}
